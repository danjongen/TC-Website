POWER SYMBOLS FOR VECTORWORKS — EXTERNAL TEST BUILD r4
=======================================================================

Thank you for testing Power Symbols.

SUPPORTED TEST ENVIRONMENT

    Vectorworks Design Suite 2026
    macOS

This is a private paid-beta build. New-placement and document-library actions
require the checkout email and PSB1 serial from the delivery email. Existing
Power Symbols remain visible and editable without activation. Please do not
redistribute the kit or serial.


INSTALL

1. Use a new disposable Vectorworks file, or back up the file you intend to use.

2. Quit Vectorworks completely.

3. Follow "01 INSTALL INSTRUCTIONS.txt". This tester delivery contains no
   unsigned double-click launcher because Gatekeeper blocks such launchers
   after they are received through WhatsApp, email or a web download.

4. Do not continue unless Terminal reports:

       Power Symbols 0.2.7 (verified)

5. Open Vectorworks 2026.

6. If Vectorworks reports an unknown third-party developer, explicitly enable
   Power Symbol and restart Vectorworks.

7. If the tool is not already in a palette, choose:

       Tools > Workspaces > Edit Current Workspace

   Find "Power Symbol" in the "Power Symbols" category and add it to a tool
   palette. Do not use a scripted palette installer.

8. Open Power Symbol Tool Preferences or **Licence / Activation…**. Enter the
   checkout email and PSB1 serial from the private delivery email. This needs
   internet once; the signed licence then verifies offline on this Mac.


RECOVERY

The installer keeps checksum-verified known-good backups. With Vectorworks
closed and Terminal working inside this tester folder, restore the previous
installed version with:

    /usr/bin/python3 "./install_power_symbols.py" rollback --version 2026

To remove the active test plug-in while retaining a recovery backup:

    /usr/bin/python3 "./install_power_symbols.py" uninstall --version 2026


FIRST FIVE MINUTES

1. Select Power Symbol in the tool palette.
2. Activate with the checkout email and serial when prompted.
3. Open Tool Preferences by double-clicking the tool or using its settings icon.
4. Hover settings or use the native ? help, choose a preset and department,
   then click Save.
5. Click repeatedly to place symbols. There should be no dialog between clicks.
6. Select a symbol and open "ⓘ Power Symbols Field Guide…" in Object Info.
7. Edit the selected symbol and confirm the marker and Full label update.
8. Edit connector, cable, notes, label side, text behavior, and colour controls
   directly in Object Info. Use More Power Data for transformer/admin fields.
9. Create or refresh the Power Distribution Schedule and presentation sheet.


IMPORTANT BEHAVIOUR

    Tool Preferences change FUTURE placements.
    Object Info fields change the SELECTED symbol.
    "Use This Symbol for New Placements" copies display defaults only.
    It does not copy circuit-specific route or connection data.
    Automatic references never silently renumber existing symbols.
    Symbol size is a printed page size; 0 uses the preset.
    Linked scaling changes marker, plate, text and spacing together.
    The schedule scans every Power Symbol in the document, not just a selection.


KNOWN LIMITATIONS

* Vectorworks 2023–2025 are packaged for compatibility work but are not
  supported by this external test.
* This is an unsigned tester delivery. It uses one Terminal command for
  installation. A customer-grade double-click installer requires Apple
  Developer ID signing and notarization.
* Adding the tool to a workspace is intentionally manual.
* This plug-in records and displays power information. It does not calculate
  loads, size conductors, check protection, or replace qualified electrical
  review.
* The document configuration migration is forward-only. Use a disposable or
  backed-up Vectorworks file.


WHAT TO RETURN

Complete TEST CHECKLIST.txt and FEEDBACK TEMPLATE.txt. Include screenshots of
anything unclear, visually incorrect, slow, or broken. If Vectorworks shows a
Script Error, capture the complete first traceback before dismissing it.
