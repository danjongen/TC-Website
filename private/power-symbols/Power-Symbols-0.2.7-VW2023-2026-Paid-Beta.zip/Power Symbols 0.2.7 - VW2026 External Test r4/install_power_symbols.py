#!/usr/bin/env python3
"""Safely install, inspect, roll back or uninstall Power Symbols.

This installer never edits a Vectorworks workspace or palette.  It verifies
the complete source, copies to a sibling staging directory, verifies the copy,
and only then performs directory renames.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import sys
import tempfile
from typing import Dict, List, Mapping, Optional, Sequence, Tuple
import zipfile


PRODUCT = "Power Symbols"
SUPPORTED_VECTORWORKS = ("2023", "2024", "2025", "2026")
DEFAULT_BACKUP_LIMIT = 3
INSTALL_MANIFEST = "INSTALL-MANIFEST.json"
INSTALL_MANIFEST_CHECKSUM = INSTALL_MANIFEST + ".sha256"
RELEASE_MANIFEST = "RELEASE-MANIFEST.json"
RELEASE_MANIFEST_CHECKSUM = RELEASE_MANIFEST + ".sha256"
INSTALL_FORMAT = "power-symbols-install-manifest-v1"
RELEASE_FORMAT = "power-symbols-release-manifest-v1"
CHECKSUM_RE = re.compile(r"^([0-9a-fA-F]{64})[ \t]+\*?([^\r\n]+)$")
MAX_ARCHIVE_FILES = 10000
MAX_ARCHIVE_BYTES = 512 * 1024 * 1024
REQUIRED_FILES = (
    "psvwx.py",
    "Power Symbol.vso",
    "VERSION",
    "vwx_power_symbols/__init__.py",
    "vwx_power_symbols/core/__init__.py",
    "vwx_power_symbols/core/models.py",
    "vwx_power_symbols/vectorworks/pio.py",
)


class InstallerError(RuntimeError):
    """A user-actionable installation or integrity failure."""


def _validate_version(version: str) -> None:
    if version not in SUPPORTED_VECTORWORKS:
        raise InstallerError("Unsupported Vectorworks version: {}".format(version))


def _reject_non_finite_json(token: str) -> None:
    raise ValueError("non-finite JSON number {}".format(token))


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        while True:
            chunk = stream.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _safe_relative_path(raw: object) -> PurePosixPath:
    if not isinstance(raw, str) or not raw or "\\" in raw:
        raise InstallerError("Manifest contains an invalid path: {!r}".format(raw))
    path = PurePosixPath(raw)
    if path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
        raise InstallerError("Manifest path escapes the release: {!r}".format(raw))
    return path


def verify_checksum(target: Path, checksum_path: Path) -> None:
    if not target.is_file():
        raise InstallerError("Required file is missing: {}".format(target.name))
    if not checksum_path.is_file():
        raise InstallerError("Checksum is missing: {}".format(checksum_path.name))
    try:
        lines = checksum_path.read_text(encoding="ascii").splitlines()
    except (OSError, UnicodeError) as error:
        raise InstallerError("Checksum is unreadable: {}".format(checksum_path.name)) from error
    if len(lines) != 1:
        raise InstallerError("Checksum file must contain exactly one entry")
    match = CHECKSUM_RE.fullmatch(lines[0])
    if not match or match.group(2) != target.name:
        raise InstallerError("Checksum file does not identify {}".format(target.name))
    if sha256_file(target).lower() != match.group(1).lower():
        raise InstallerError("SHA-256 mismatch for {}".format(target.name))


def verify_manifest_tree(
    root: Path,
    manifest_name: str,
    checksum_name: str,
    expected_format: str,
    strict: bool = True,
) -> Tuple[Mapping[str, object], List[str]]:
    manifest_path = root / manifest_name
    verify_checksum(manifest_path, root / checksum_name)
    try:
        manifest = json.loads(
            manifest_path.read_text(encoding="utf-8"),
            parse_constant=_reject_non_finite_json,
        )
    except (OSError, UnicodeError, ValueError) as error:
        raise InstallerError("{} is not valid JSON".format(manifest_name)) from error
    if not isinstance(manifest, dict) or manifest.get("format") != expected_format:
        raise InstallerError("{} has an unsupported format".format(manifest_name))
    if manifest.get("product") != PRODUCT:
        raise InstallerError("{} identifies a different product".format(manifest_name))
    if manifest.get("hash_algorithm") != "sha256":
        raise InstallerError("{} does not use SHA-256".format(manifest_name))
    entries = manifest.get("files")
    if not isinstance(entries, list):
        raise InstallerError("{} has no file list".format(manifest_name))

    expected = set()
    for entry in entries:
        if not isinstance(entry, dict):
            raise InstallerError("{} contains an invalid entry".format(manifest_name))
        relative = _safe_relative_path(entry.get("path"))
        name = relative.as_posix()
        if name in expected:
            raise InstallerError("{} lists {} twice".format(manifest_name, name))
        expected.add(name)
        path = root.joinpath(*relative.parts)
        if path.is_symlink() or not path.is_file():
            raise InstallerError("Manifest file is missing or unsafe: {}".format(name))
        size = entry.get("size")
        digest = entry.get("sha256")
        if not isinstance(size, int) or size < 0 or path.stat().st_size != size:
            raise InstallerError("File size mismatch: {}".format(name))
        if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
            raise InstallerError("Invalid SHA-256 entry for {}".format(name))
        if sha256_file(path) != digest:
            raise InstallerError("File checksum mismatch: {}".format(name))

    expected_directories = set()
    for name in expected:
        for parent in PurePosixPath(name).parents:
            if parent != PurePosixPath("."):
                expected_directories.add(parent.as_posix())

    excluded = {manifest_name, checksum_name}
    actual = set()
    actual_directories = set()
    for path in root.rglob("*"):
        if path.is_symlink():
            raise InstallerError("Tree contains a symbolic link: {}".format(path.name))
        name = path.relative_to(root).as_posix()
        if path.is_file():
            if name not in excluded:
                actual.add(name)
        elif path.is_dir():
            actual_directories.add(name)
        else:
            raise InstallerError(
                "Tree contains an unsupported filesystem entry: {}".format(name)
            )
    missing = sorted(expected - actual)
    unexpected = sorted(actual - expected)
    unexpected.extend(
        name + "/" for name in sorted(actual_directories - expected_directories)
    )
    if missing:
        raise InstallerError("Manifest files are missing: {}".format(", ".join(missing)))
    if strict and unexpected:
        raise InstallerError(
            "Unlisted filesystem entries are present: {}".format(
                ", ".join(unexpected)
            )
        )
    return manifest, unexpected


def validate_plugin_shape(source: Path) -> None:
    missing = [name for name in REQUIRED_FILES if not (source / name).is_file()]
    if missing:
        raise InstallerError(
            "Source is not a complete Power Symbols plug-in (missing: {}).".format(
                ", ".join(missing)
            )
        )
    if (source / "Power Symbol.vso").read_bytes()[:4] != b"MCVS":
        raise InstallerError("Power Symbol.vso is not a Vectorworks plug-in resource")


def validate_source(source: Path) -> Mapping[str, object]:
    if not source.is_dir() or source.is_symlink():
        raise InstallerError("Built plug-in folder not found: {}".format(source))
    validate_plugin_shape(source)
    manifest, _ = verify_manifest_tree(
        source,
        INSTALL_MANIFEST,
        INSTALL_MANIFEST_CHECKSUM,
        INSTALL_FORMAT,
        strict=True,
    )
    version = manifest.get("version")
    version_path = source / "VERSION"
    if (
        not isinstance(version, str)
        or not version
        or not version_path.is_file()
        or version_path.read_text(encoding="ascii").strip() != version
    ):
        raise InstallerError("VERSION does not match the install manifest")
    supported = manifest.get("supported_vectorworks")
    if supported != list(SUPPORTED_VECTORWORKS):
        raise InstallerError("Install manifest has an unexpected compatibility range")
    return manifest


def vectorworks_root(version: str, home: Optional[Path] = None) -> Path:
    _validate_version(version)
    base = Path.home() if home is None else Path(home)
    return base / "Library" / "Application Support" / "Vectorworks" / version


def destination_for(version: str, home: Optional[Path] = None) -> Path:
    return vectorworks_root(version, home) / "Plug-ins" / PRODUCT


def backup_root_for(version: str, home: Optional[Path] = None) -> Path:
    return vectorworks_root(version, home) / "Power Symbols Backups"


def timestamp() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%fZ")


def backup_directories(root: Path) -> List[Path]:
    if root.is_symlink():
        raise InstallerError("Backup location must not be a symbolic link")
    if not root.is_dir():
        return []
    values = [
        path
        for path in root.iterdir()
        if path.is_dir()
        and not path.is_symlink()
        and path.name.startswith("Power Symbols-")
    ]
    return sorted(values, key=lambda path: (path.stat().st_mtime_ns, path.name))


def prune_backups(root: Path, limit: int) -> List[Path]:
    if not 0 <= limit <= 100:
        raise InstallerError("Backup limit must be between 0 and 100")
    values = backup_directories(root)
    removed = []
    while len(values) > limit:
        oldest = values.pop(0)
        shutil.rmtree(oldest)
        removed.append(oldest)
    if root.is_dir() and not any(root.iterdir()):
        root.rmdir()
    return removed


def _move_verified_live_to_backup(
    destination: Path, backup_root: Path, label: str
) -> Path:
    validate_source(destination)
    if destination.is_symlink() or backup_root.is_symlink():
        raise InstallerError("Live and backup locations must not be symbolic links")
    backup_root.mkdir(parents=True, exist_ok=True)
    backup = backup_root / "Power Symbols-{}-{}".format(label, timestamp())
    destination.rename(backup)
    os.utime(str(backup), None)
    return backup


def _path_exists(path: Path) -> bool:
    return path.exists() or path.is_symlink()


def _remove_path(path: Path) -> None:
    if path.is_symlink() or path.is_file():
        path.unlink()
    elif path.is_dir():
        shutil.rmtree(path)


def install_source(
    source: Path,
    version: str,
    backup_limit: int = DEFAULT_BACKUP_LIMIT,
    home: Optional[Path] = None,
) -> Tuple[Path, Mapping[str, object]]:
    _validate_version(version)
    source = source.expanduser().resolve()
    manifest = validate_source(source)
    if version not in manifest["supported_vectorworks"]:
        raise InstallerError("Release does not support Vectorworks {}".format(version))
    destination = destination_for(version, home)
    if source == destination.resolve():
        raise InstallerError("Source and installed destination are the same folder")
    if destination.is_symlink():
        raise InstallerError("Installed destination must not be a symbolic link")
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = destination.parent / ".Power Symbols.installing-{}".format(timestamp())
    displaced = None
    displaced_is_backup = False
    activated = False
    backup_root = backup_root_for(version, home)
    try:
        shutil.copytree(source, staging)
        staged_manifest = validate_source(staging)
        if staged_manifest.get("version") != manifest.get("version"):
            raise InstallerError("Staged version changed during installation")
        if destination.exists():
            # Only a fully verified install may enter the known-good backups.
            try:
                displaced = _move_verified_live_to_backup(
                    destination, backup_root, "upgrade"
                )
                displaced_is_backup = True
            except InstallerError:
                displaced = destination.parent / ".Power Symbols.invalid-{}".format(
                    timestamp()
                )
                destination.rename(displaced)
        staging.rename(destination)
        activated = True
        validate_source(destination)
    except Exception:
        if _path_exists(staging):
            _remove_path(staging)
        if activated and _path_exists(destination):
            _remove_path(destination)
        if (
            displaced is not None
            and _path_exists(displaced)
            and not _path_exists(destination)
        ):
            displaced.rename(destination)
        raise
    if (
        displaced is not None
        and not displaced_is_backup
        and _path_exists(displaced)
    ):
        _remove_path(displaced)
    prune_backups(backup_root, backup_limit)
    return destination, manifest


def safe_extract(archive: Path, destination: Path) -> None:
    seen = set()
    seen_casefold = set()
    with zipfile.ZipFile(archive) as release:
        members = release.infolist()
        if len(members) > MAX_ARCHIVE_FILES:
            raise InstallerError("Release archive contains too many files")
        if sum(member.file_size for member in members) > MAX_ARCHIVE_BYTES:
            raise InstallerError("Release archive expands beyond the safety limit")
        for member in members:
            if member.flag_bits & 0x1:
                raise InstallerError("Release archive contains an encrypted member")
            if member.compress_type not in (
                zipfile.ZIP_STORED,
                zipfile.ZIP_DEFLATED,
            ):
                raise InstallerError("Release archive uses unsupported compression")
            raw = member.filename[:-1] if member.filename.endswith("/") else member.filename
            if not raw:
                continue
            relative = _safe_relative_path(raw)
            name = relative.as_posix()
            folded = name.casefold()
            if name in seen or folded in seen_casefold:
                raise InstallerError(
                    "Release archive contains a duplicate path: {}".format(name)
                )
            seen.add(name)
            seen_casefold.add(folded)
            mode = (member.external_attr >> 16) & 0xFFFF
            if stat.S_IFMT(mode) == stat.S_IFLNK:
                raise InstallerError(
                    "Release archive contains a symbolic link: {}".format(name)
                )
            target = destination.joinpath(*relative.parts)
            if member.is_dir():
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            if target.exists():
                raise InstallerError(
                    "Release archive would overwrite a path: {}".format(name)
                )
            with release.open(member, "r") as source, target.open("xb") as output:
                shutil.copyfileobj(source, output)


def install_archive(
    archive: Path,
    checksum: Path,
    version: str,
    backup_limit: int = DEFAULT_BACKUP_LIMIT,
    home: Optional[Path] = None,
) -> Tuple[Path, Mapping[str, object]]:
    _validate_version(version)
    archive = archive.expanduser().resolve()
    checksum = checksum.expanduser().resolve()
    verify_checksum(archive, checksum)
    with tempfile.TemporaryDirectory(prefix="power-symbols-release-") as temporary:
        release_root = Path(temporary)
        safe_extract(archive, release_root)
        verify_manifest_tree(
            release_root,
            RELEASE_MANIFEST,
            RELEASE_MANIFEST_CHECKSUM,
            RELEASE_FORMAT,
            strict=True,
        )
        return install_source(
            release_root / PRODUCT,
            version,
            backup_limit=backup_limit,
            home=home,
        )


def inspect_plugin(path: Path) -> Dict[str, object]:
    installed = _path_exists(path)
    result: Dict[str, object] = {
        "installed": installed,
        "location": str(path),
        "version": None,
        "source_revision": None,
        "built_at_utc": None,
        "integrity": "absent",
        "unexpected_files": [],
    }
    if not installed:
        return result
    try:
        manifest = validate_source(path)
        result.update(
            {
                "version": manifest.get("version"),
                "source_revision": manifest.get("source_revision"),
                "built_at_utc": manifest.get("built_at_utc"),
                "integrity": "verified",
            }
        )
    except (InstallerError, OSError, UnicodeError) as error:
        result["integrity"] = "failed"
        result["error"] = str(error)
    return result


def status_report(version: str, home: Optional[Path] = None) -> Dict[str, object]:
    live = destination_for(version, home)
    backups = []
    for backup in reversed(backup_directories(backup_root_for(version, home))):
        details = inspect_plugin(backup)
        details["name"] = backup.name
        details.pop("location", None)
        backups.append(details)
    return {
        "product": PRODUCT,
        "vectorworks_version": version,
        "live": inspect_plugin(live),
        "backups": backups,
    }


def rollback(
    version: str,
    backup_name: Optional[str] = None,
    backup_limit: int = DEFAULT_BACKUP_LIMIT,
    home: Optional[Path] = None,
) -> Path:
    destination = destination_for(version, home)
    backup_root = backup_root_for(version, home)
    if destination.is_symlink():
        raise InstallerError("Installed destination must not be a symbolic link")
    choices = backup_directories(backup_root)
    if backup_name:
        if Path(backup_name).name != backup_name:
            raise InstallerError("Backup must be a name, not a path")
        choices = [path for path in choices if path.name == backup_name]
    if not choices:
        raise InstallerError("No matching known-good Power Symbols backup is available")
    selected = choices[-1]
    validate_source(selected)
    destination.parent.mkdir(parents=True, exist_ok=True)
    staging = destination.parent / ".Power Symbols.rolling-back-{}".format(
        timestamp()
    )
    displaced = None
    displaced_is_backup = False
    activated = False
    try:
        shutil.copytree(selected, staging)
        validate_source(staging)
        if destination.exists():
            try:
                displaced = _move_verified_live_to_backup(
                    destination, backup_root, "before-rollback"
                )
                displaced_is_backup = True
            except InstallerError:
                displaced = destination.parent / ".Power Symbols.invalid-{}".format(
                    timestamp()
                )
                destination.rename(displaced)
        staging.rename(destination)
        activated = True
        validate_source(destination)
    except Exception:
        if _path_exists(staging):
            _remove_path(staging)
        if activated and _path_exists(destination):
            _remove_path(destination)
        if (
            displaced is not None
            and _path_exists(displaced)
            and not _path_exists(destination)
        ):
            displaced.rename(destination)
        raise
    shutil.rmtree(selected)
    if (
        displaced is not None
        and not displaced_is_backup
        and _path_exists(displaced)
    ):
        _remove_path(displaced)
    prune_backups(backup_root, backup_limit)
    return destination


def uninstall(
    version: str,
    purge: bool = False,
    purge_backups: bool = False,
    backup_limit: int = DEFAULT_BACKUP_LIMIT,
    home: Optional[Path] = None,
) -> Optional[Path]:
    destination = destination_for(version, home)
    backup_root = backup_root_for(version, home)
    saved = None
    if destination.exists():
        if destination.is_symlink():
            raise InstallerError("Installed destination must not be a symbolic link")
        if purge:
            shutil.rmtree(destination)
        else:
            saved = _move_verified_live_to_backup(
                destination, backup_root, "uninstalled"
            )
            prune_backups(backup_root, backup_limit)
            if not saved.exists():
                saved = None
    if purge_backups and backup_root.exists():
        if backup_root.is_symlink():
            raise InstallerError("Backup location must not be a symbolic link")
        shutil.rmtree(backup_root)
        saved = None
    return saved


def default_source() -> Path:
    root = Path(__file__).resolve().parents[1]
    built = root / "Plug-ins" / PRODUCT
    extracted = root / PRODUCT
    return built if built.is_dir() else extracted


def backup_limit(raw: str) -> int:
    try:
        value = int(raw)
    except ValueError as error:
        raise argparse.ArgumentTypeError("must be an integer") from error
    if not 0 <= value <= 100:
        raise argparse.ArgumentTypeError("must be between 0 and 100")
    return value


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)

    install = commands.add_parser("install", help="verify and install a release")
    install.add_argument("--version", choices=SUPPORTED_VECTORWORKS, required=True)
    source = install.add_mutually_exclusive_group()
    source.add_argument("--source", help="extracted Power Symbols plug-in folder")
    source.add_argument("--archive", help="versioned release ZIP")
    install.add_argument("--checksum", help="archive checksum (defaults to ZIP.sha256)")
    install.add_argument(
        "--backup-limit", type=backup_limit, default=DEFAULT_BACKUP_LIMIT
    )

    status_parser = commands.add_parser(
        "status", help="show installed version and integrity"
    )
    status_parser.add_argument(
        "--version", choices=SUPPORTED_VECTORWORKS, required=True
    )
    status_parser.add_argument("--json", action="store_true")

    rollback_parser = commands.add_parser(
        "rollback", help="restore the latest known-good backup"
    )
    rollback_parser.add_argument(
        "--version", choices=SUPPORTED_VECTORWORKS, required=True
    )
    rollback_parser.add_argument("--backup", help="specific backup directory name")
    rollback_parser.add_argument(
        "--backup-limit", type=backup_limit, default=DEFAULT_BACKUP_LIMIT
    )

    uninstall_parser = commands.add_parser(
        "uninstall", help="remove the live plug-in"
    )
    uninstall_parser.add_argument(
        "--version", choices=SUPPORTED_VECTORWORKS, required=True
    )
    uninstall_parser.add_argument(
        "--purge", action="store_true", help="delete live files without a backup"
    )
    uninstall_parser.add_argument(
        "--purge-backups", action="store_true", help="also delete all backups"
    )
    uninstall_parser.add_argument(
        "--backup-limit", type=backup_limit, default=DEFAULT_BACKUP_LIMIT
    )
    return parser


def _normalise_install_args(arguments: Sequence[str]) -> List[str]:
    values = list(arguments)
    if values and values[0] not in ("-h", "--help") and values[0].startswith("-"):
        return ["install"] + values
    return values


def print_human_status(report: Mapping[str, object]) -> None:
    live = report["live"]
    assert isinstance(live, dict)
    if not live["installed"]:
        print(
            "Power Symbols is not installed for Vectorworks {}.".format(
                report["vectorworks_version"]
            )
        )
    else:
        print(
            "Power Symbols {} ({})".format(
                live.get("version") or "unknown", live["integrity"]
            )
        )
        print(live["location"])
        if live.get("error"):
            print("Integrity error: {}".format(live["error"]))
        unexpected = list(live.get("unexpected_files") or ())
        if unexpected:
            print("Unexpected files: {}".format(", ".join(unexpected[:10])))
    print("Known-good backups: {}".format(len(report["backups"])))


def main(argv: Optional[Sequence[str]] = None) -> int:
    raw = sys.argv[1:] if argv is None else list(argv)
    args = create_parser().parse_args(_normalise_install_args(raw))
    try:
        if args.command == "install":
            if args.archive:
                archive = Path(args.archive)
                checksum = (
                    Path(args.checksum)
                    if args.checksum
                    else Path(str(archive) + ".sha256")
                )
                destination, manifest = install_archive(
                    archive,
                    checksum,
                    args.version,
                    backup_limit=args.backup_limit,
                )
            else:
                if args.checksum:
                    raise InstallerError("--checksum is only valid with --archive")
                source = Path(args.source) if args.source else default_source()
                destination, manifest = install_source(
                    source, args.version, backup_limit=args.backup_limit
                )
            print(
                "Installed Power Symbols {} for Vectorworks {}.".format(
                    manifest["version"], args.version
                )
            )
            print(destination)
            return 0
        if args.command == "status":
            report = status_report(args.version)
            if args.json:
                print(json.dumps(report, indent=2, sort_keys=True, allow_nan=False))
            else:
                print_human_status(report)
            if not report["live"]["installed"]:
                return 1
            return 0 if report["live"]["integrity"] == "verified" else 2
        if args.command == "rollback":
            destination = rollback(
                args.version, args.backup, backup_limit=args.backup_limit
            )
            print("Restored Power Symbols for Vectorworks {}.".format(args.version))
            print(destination)
            return 0
        if args.command == "uninstall":
            saved = uninstall(
                args.version,
                purge=args.purge,
                purge_backups=args.purge_backups,
                backup_limit=args.backup_limit,
            )
            print("Power Symbols is not active for Vectorworks {}.".format(args.version))
            if saved:
                print("Recovery backup: {}".format(saved))
            return 0
        raise InstallerError("Unknown command")
    except (InstallerError, OSError, UnicodeError, zipfile.BadZipFile) as error:
        raise SystemExit("Power Symbols installer: {}".format(error))


if __name__ == "__main__":
    raise SystemExit(main())
